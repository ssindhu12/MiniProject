﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyHousingSolutionEntity
{
    public class Images
    {
        public int ImageId { get; set; }
        public int PropertyId { get; set; }
        public string Image { get; set; }
    }
}
