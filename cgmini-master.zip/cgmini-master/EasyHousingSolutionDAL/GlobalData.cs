﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyHousingSolutionDAL
{
     static class GlobalData
    {
        public static string ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_12Dec18_Bangalore;Persist Security Info=True;User ID=sqluser;Password=sqluser";
    }
}
